$(function(){
  $("#formularioimagem").submit(function(event){
    event.preventDefault(); // prevent default submit behaviour
    // get values from FORM

    $("#arquivo").removeAttr("type").attr("type", "file");

    var nome = $("#arquivo").val();

    $.ajax({
        url: 'https://node-red-bluemix-starter-conceptdemo-1322.mybluemix.net/uploadurl', // Url do lado server que vai receber o arquivo
        data: {"title": nome},
        cache: false,
        type: 'POST',
        success: function (data) {
            // utilizar o retorno
            console.log("ok");
        },
        error: function(){
          console.log("e");
        }
    });

    window.location.assign("alerta3.html");
  });
});
